<!DOCTYPE html>
<html>

<head>

  <meta charset="UTF-8">

  <title>KOMIKGRAM </title>
  <link rel="icon" type="image/x-icon" href="images/KOMIK.png">
  <link rel="stylesheet" href="css/reset.css">

    <link rel="stylesheet" href="css/style.css" media="screen" type="text/css" />

</head>

<body>
<form action="proses_login.php" method="post">
  <div class="wrap">
		<div class="avatar">
      <img src="images/KOMIK.png">
		</div>
		<input type="text" name ="username" placeholder="username" required>
		<div class="bar">
			<i></i>
		</div>
		<input type="password" name="password" placeholder="password" required><br>
		<button>Sign in</button>
	</div>

  <script src="js/index.js"></script>
  </form>
</body>

</html>