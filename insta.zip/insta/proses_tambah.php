<?php 
session_start();
if(!isset($_SESSION['login'])) {
  header("location:login.php?pesan=logindulu"); 
}
include "koneksi.php";
require "functions.php";

if(isset($_POST['simpan'])) {
    $caption = $_POST['caption'];
    $lokasi = $_POST['lokasi'];
    $foto = upload();

    $sql = "INSERT INTO post (foto,caption,lokasi) VALUES ('$foto','$caption','$lokasi')";
    $query = mysqli_query($koneksi,$sql);

    if($query) {
        header ("location:index.php?simpan=berhasil");
    } else {
        header ("location:index.php?simpan=gagal");
    }
}
?>