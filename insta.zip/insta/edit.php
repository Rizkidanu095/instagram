<?php 
session_start();
if(!isset($_SESSION['login'])) {
  header("location:login.php?pesan=logindulu"); 
}
include "koneksi.php";
$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no='$no'";
$query = mysqli_query($koneksi,$sql);
while ($post = mysqli_fetch_assoc($query)) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="icon" type="image/x-icon" href="images/KOMIK.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <div class="container">   
    <div class="card">
  <div class="card-body">
     <h1 class="fw-bold">EDIT</h1>
    <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?=$post['no']?>">
        <input type="hidden" name="foto_lama" value="<?=$post['foto']?>">
        <label for="" class="fw-bold">FOTO</label><br>
        <input type="file" name="foto" id="" value="<?=$post['foto']?>"class="form-control" ><br>
        <img src="images/<?= $post['foto'] ?>" width="100" alt="" class="mb-3"><br>

        <label for="" class="fw-bold">CAPTION</label><br>
        <input type="text" name="caption" id="" value="<?=$post['caption']?>"class="form-control" ><br>

        <label for="" class="fw-bold">LOKASI    </label><br>
        <input type="text" name="lokasi" id="" value="<?=$post['lokasi']?>" class="form-control" ><br>
        <input type="submit" value="update" name="update" class="btn btn-primary">
    </form>
    </div>
    </div>

    </div>


</body>
</html>



<?php } ?>