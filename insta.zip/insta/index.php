<?php 
session_start();
if(!isset($_SESSION['login'])) {
  header("location:login.php?pesan=logindulu"); 
}
include "koneksi.php";
$sql = "SELECT * FROM post";
$query = mysqli_query($koneksi,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>KOMIKGRAM</title>
    <link rel="icon" type="image/x-icon" href="images/KOMIK.png">
    <style>
  body{
      margin: 0;
      padding: 0;
      background: url(images/bg3.jpg) no-repeat;
      
      font-family: sans-serif;
      background-size: cover;
      background-repeat: no-repeat ;
      background-position: center;
    }
.zoom {
  overflow:hidden;
  border-radius:3px;
}
.zoom img{
  
  transition: transform .2s; /* Animation */
  margin:0 auto;
}

.zoom:hover img{
  transform: scale(1.3); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-primary sticky-top" data-bs-theme="dark">
  <div class="container-fluid">
  <i class="fa-brands fa-instagram" style="font-size:35px;"></i>
  <img src="images/KOMIK.png" height="65" width="80" >
   <a class="navbar-brand fw-bold" href="index.php" >KOMIKGRAM</a>
    <!-- <a class="navbar-brand" href="#"><img src="images/insta.png" width="25" alt="" srcset=""></a> -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      </ul>
              <span class="navbar-text">
                <button type="button" class="btn btn-success bi bi-plus-square" data-bs-toggle="modal" data-bs-target="#exampleModal"></button>

              </span> |
              <a href="logout.php" class="btn btn-danger"><i class="bi bi-box-arrow-right"></i></a>

        <!-- <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" aria-disabled="true">Disabled</a>
        </li>
      </ul> -->
      <!-- <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form> -->
      
    </div>
  </div>
</nav>
<!-- Modal tambah-->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5 fw-bold" id="exampleModalLabel">TAMBAH</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        <label for="" class="fw-bold">Foto</label>
        <input type="file" name="foto" class="form-control fw-bold" required><br>

        <label for="" class="fw-bold">Caption</label>
        <input type="text" name="caption" class="form-control"autocomplete="off"><br>

        <label for="" class="fw-bold">Lokasi</label>
        <input type="text" name="lokasi" class="form-control"autocomplete="off"><br>
      </div>
      <div class="modal-footer">
      <input class="btn btn-success" type="submit" value="Post" name="simpan">
        </div>
      </form>
    </div>
  </div>
</div>


<?php while ($post = mysqli_fetch_assoc($query)) { ?>
    <div class="container">
  <div class="row mt-4 justify-content-center">
      <div class="col-md-4 mb-4 ">
        <div class="card shadow-lg p-3 mb-2 bg-white rounded" >
          <div class="zoom">
          <img src="images/<?= $post['foto'] ?>" alt="" width="100" class="zoom card-img-top" alt="...">
          </div>
          <div class="card-body">
            <h5 class="card-title"><?= $post['lokasi'] ?></h5>
            <p class="card-text"><?= $post['caption'] ?></p>
            <a href="" type="button" class = "btn btn-outline btn-warning" data-bs-toggle="modal" data-bs-target="#ModalEdit<?=$post['no']?>"><i class="bi bi-pencil-square"></i></a>
            <a href="hapus.php?no=<?= $post['no'] ?>" class = "btn btn-danger" onclick ="return confirm('Anda ingin hapus postingan ini?')"><i class="bi bi-trash-fill"></i></a><br><br>
          </div>
        </div>
      </div>

     
      <!-- Modal edit-->
<div class="modal fade" id="ModalEdit<?=$post['no']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5 fw-bold" id="exampleModalLabel">EDIT</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?=$post['no']?>">
        <input type="hidden" name="foto_lama" value="<?=$post['foto']?>">

        <label for="" class="fw-bold">Foto</label>
        <input type="file" name="foto" class="form-control fw-bold" value="<?=$post['foto']?>"><br>
        <img src="images/<?= $post['foto'] ?>" width="80" alt="" class="mb-3"><br>

        <label for="" class="fw-bold">Caption</label>
        <input type="text" name="caption" class="form-control"autocomplete="off" value="<?=$post['caption']?>"><br>

        <label for="" class="fw-bold">Lokasi</label>
        <input type="text" name="lokasi" class="form-control"autocomplete="off" value="<?=$post['lokasi']?>"><br>
      </div>
      <div class="modal-footer">
      <input class="btn btn-success" type="submit" value="Post" name="update">
        </div>
      </form>
    </div>
  </div>
</div>
</div>
</div>
</div>
<?php } ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>


</body>
</html>